# 问题1 EDA 摘要

## 样本规模

记录数: 1082


## 描述性统计（关键变量）

- gestational_week: count=1082, mean=16.846, std=4.076, min=11.000, 25%=13.286, 50%=16.000, 75%=20.000, max=29.000
- bmi: count=1082, mean=32.289, std=2.972, min=20.703, 25%=30.209, 50%=31.812, 75%=33.926, max=46.875
- y_concentration: count=1082, mean=0.077, std=0.034, min=0.010, 25%=0.051, 50%=0.075, 75%=0.099, max=0.234

## 相关性 (Pearson)

- gestational_week: gestational_week=1.000, bmi=0.150, y_concentration=0.127
- bmi: gestational_week=0.150, bmi=1.000, y_concentration=-0.151
- y_concentration: gestational_week=0.127, bmi=-0.151, y_concentration=1.000

## 生成图表

- figures/distributions.png
- figures/scatter_week_vs_y.png
- figures/scatter_bmi_vs_y.png
- figures/box_y_by_bmi_group.png
- figures/corr_heatmap.png
