# 预处理日志
- 启用规则：QC过滤、BMI复算、同孕周去重(0.1周)、1%-99%温莎化
- QC规则：40%≤GC≤60%，AA≤0.30，L>1e6，0.60≤M≤0.98，N≤0.50
- 清洗后样本数：605

## 统计摘要(含处理前后规模)

|                   |   count |        mean |         std |         min |         25% |         50% |         75% |        max |   missing |
|:------------------|--------:|------------:|------------:|------------:|------------:|------------:|------------:|-----------:|----------:|
| gestational_week  |     605 |  16.51      |   3.95029   |  11         |  13.1429    |  15.7143    |  19.8571    |  29        |         0 |
| bmi               |     605 |  32.256     |   2.72681   |  27.8821    |  30.3006    |  31.8393    |  33.8898    |  40.404    |         0 |
| y_concentration   |     605 |   0.0767762 |   0.0310898 |   0.0238519 |   0.0521932 |   0.0750442 |   0.0987056 |   0.164884 |         0 |
| rows_before_qc    |    1082 | nan         | nan         | nan         | nan         | nan         | nan         | nan        |       nan |
| rows_after_qc     |     630 | nan         | nan         | nan         | nan         | nan         | nan         | nan        |       nan |
| rows_before_dedup |     630 | nan         | nan         | nan         | nan         | nan         | nan         | nan        |       nan |
| rows_after_dedup  |     605 | nan         | nan         | nan         | nan         | nan         | nan         | nan        |       nan |
| qc_rules          |       5 | nan         | nan         | nan         | nan         | nan         | nan         | nan        |       nan |